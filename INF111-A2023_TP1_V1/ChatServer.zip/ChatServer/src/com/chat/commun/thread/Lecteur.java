package com.chat.commun.thread;

/**
 * Cette interface repr�sente un objet qui fournit une m�thode de lecture, typiquement un client ou un serveur.
 *
 * @author Abdelmoum�ne Toudeft (Abdelmoumene.Toudeft@etsmtl.ca)
 * @version 1.0
 * @since 2023-09-01
 */
public interface Lecteur {
    /**
     * M�thode de lecture
     */
    void lire();
}
